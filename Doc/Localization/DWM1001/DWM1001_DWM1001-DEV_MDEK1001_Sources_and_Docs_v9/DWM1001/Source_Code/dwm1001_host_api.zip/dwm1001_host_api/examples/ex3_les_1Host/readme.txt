test_les.c

Purpose: Setup the node as a tag and print out the RTLS info through UART APIs. 

Descriptions:

In this example, the steps to configure the Tag include:
 Tag mode, PANID, encryption key, update rate. 
According to the network settings, some of these settings 
are not necessary.

